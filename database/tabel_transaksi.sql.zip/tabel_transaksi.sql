-- phpMyAdmin SQL Dump
-- version 3.2.4
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Dec 04, 2010 at 02:44 
-- Server version: 5.1.41
-- PHP Version: 5.3.1

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `akuntansi_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `tabel_transaksi`
--

CREATE TABLE IF NOT EXISTS `tabel_transaksi` (
  `id_transaksi` int(15) NOT NULL AUTO_INCREMENT,
  `kode_transaksi` varchar(15) NOT NULL,
  `kode_rekening` varchar(10) NOT NULL,
  `tanggal_transaksi` varchar(12) NOT NULL,
  `jenis_transaksi` varchar(15) NOT NULL,
  `keterangan_transaksi` text NOT NULL,
  `debet` int(15) NOT NULL,
  `kredit` int(15) NOT NULL,
  `tanggal_posting` varchar(12) NOT NULL,
  `keterangan_posting` varchar(10) NOT NULL,
  `id_admin` int(4) NOT NULL,
  PRIMARY KEY (`id_transaksi`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=57 ;

--
-- Dumping data for table `tabel_transaksi`
--

INSERT INTO `tabel_transaksi` (`id_transaksi`, `kode_transaksi`, `kode_rekening`, `tanggal_transaksi`, `jenis_transaksi`, `keterangan_transaksi`, `debet`, `kredit`, `tanggal_posting`, `keterangan_posting`, `id_admin`) VALUES
(50, 'BU/1', '133.02', '03/12/2010', 'Bukti Umum', 'Pembelian Komputer', 2000000, 0, '03/12/2010', 'Post', 1),
(49, 'BU/1', '111.01', '03/12/2010', 'Bukti Umum', 'Pembelian Komputer', 0, 2000000, '03/12/2010', 'Post', 1),
(51, 'BU/2', '111.01', '03/12/2010', 'Bukti Umum', 'Pendapatan Toko Koperasi', 5000000, 0, '03/12/2010', 'Post', 1),
(52, 'BU/2', '411.01', '03/12/2010', 'Bukti Umum', 'Pendapatan Toko Koperasi', 0, 5000000, '03/12/2010', 'Post', 1),
(53, 'KK/1', '111.01', '03/12/2010', 'Kas Keluar', 'Pembelian Komputer', 0, 35000000, '03/12/2010', 'Post', 1),
(54, 'KK/1', '133.02', '03/12/2010', 'Kas Keluar', 'Pembelian Komputer', 10000000, 0, '03/12/2010', 'Post', 1),
(55, 'KK/1', '133.01', '03/12/2010', 'Kas Keluar', 'Pembelian Mesin Ketik', 5000000, 0, '03/12/2010', 'Post', 1),
(56, 'KK/1', '133.03', '03/12/2010', 'Kas Keluar', 'Pembelian Mesin Foto Copy', 20000000, 0, '03/12/2010', 'Post', 1);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
